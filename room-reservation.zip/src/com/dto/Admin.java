package com.dto;

public class Admin {
    String a_id;
    String a_pwd;
    String a_name;
}

