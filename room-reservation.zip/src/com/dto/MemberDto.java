package com.dto;

public class MemberDto {
    String m_id;
    String m_pwd;
    String m_name;
    String m_birth;
    String m_phone;
    String m_email;
}
