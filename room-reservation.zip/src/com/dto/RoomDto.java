package com.dto;

public class RoomDto {
    int r_no;
    String t_name;
    String r_status;
}
