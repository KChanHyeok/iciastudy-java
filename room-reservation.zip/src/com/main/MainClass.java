package com.main;

import com.controller.ControllerClass;

public class MainClass {
    public static void main(String[] args) {
        ControllerClass bc = new ControllerClass();
        bc.run();
    }
}
